import os
import testmu
from testmu import expect, var, set_var
from playwright.async_api import Page

testmu.configure(
    build="5f60a54c-f9d2-40b3-b6a0-cb2e18ae3122",
    name="Add iPhone to Cart and View Cart",
    tc_id="TC-95",
    network=os.getenv("NETWORK", "false").lower() == "true",
    variables={"shopping_cart_check": "Shopping Cart"},
    test_params={"Email": "prince.ronquillo@bnext.tech", "login_cert": "test.account@gmail.com", "Password": "Pcr!199617pcr2", "password_cert": "Testaccount123", "Username": "PRONQUILLO"},
    global_variables=[{"id": 143728, "name": "Asset_Class", "value": "3200", "session_value": "3200", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 143727, "name": "Company_Code", "value": "5810", "session_value": "5810", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 143752, "name": "Cost_Center", "value": "58101501", "session_value": "58101501", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 337953, "name": "product_cert", "value": "iPhone", "session_value": "iPhone", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 133664, "name": "Username", "value": "PRONQUILLO", "session_value": "PRONQUILLO", "is_persist": False, "environment_id": 0, "environment_name": "No Env"}],
    auto_heal_version="AH2",
    default_action_timeout_ms=60000,
    default_navigation_timeout_ms=60000,
    kane_run_v4=True,
)

@testmu.test
async def test(page: Page):
    async with testmu.step('Navigate to https://ecommerce-playground.lambdatest.io/index.php?route=common/home', instruction_id='d3006f57e1e744c4aed790622abb1ac6'):
        await page.goto("https://ecommerce-playground.lambdatest.io/index.php?route=common/home")
    
    async with testmu.step('Typing product search query', instruction_id='afe2e706183c4666b26bf88acc0cfb65'):
        element_0 = page.locator("internal:role=textbox[name=\"Search For Products\"i]")
        variable_value_1 = var('{{global.product_cert}}')
        
        try:
            await element_0.click(timeout=2000)
        except Exception:
            pass
        await element_0.fill(testmu.as_text(variable_value_1))
    
    async with testmu.step('Clicking the SEARCH button in the site header search form', instruction_id='4bbfa434830843b18b55c76f904e282a'):
        _loc_1 = page.locator("internal:role=button[name=\"Search\"i]")
        
        await _loc_1.click()
    
    async with testmu.step('Hover over the first product search result card, the leftmost iPhone item linked to product_id=40 beneath the Search - iPhone heading', instruction_id='4c3e16139af9492ba2a17f517d96971e'):
        coords = await testmu.get_vision_coordinates(page, 'Hover over the first product search result card, the leftmost iPhone item linked to product_id=40 beneath the Search - iPhone heading', "click", 546, 625)
        await page.mouse.move(coords['x'], coords['y'])
        
    
    async with testmu.step('Waiting briefly after hovering the first iPhone search result', instruction_id='aa673f116a7a4fc0be6c0680ac4e1189'):
        await page.wait_for_timeout(500)
    
    async with testmu.step('Clicking Add to Cart for the first iPhone product', instruction_id='20de7830d08b4226b50efcb777d0a172'):
        _loc_2 = page.locator("internal:attr=[title=\"Add to Cart\"i] >> nth=0")
        
        await _loc_2.click()
    
    async with testmu.step('Clicking View Cart in the top-right header', instruction_id='5b18dc9239c0481fb33a16f7e03cd41c'):
        _loc_3 = page.locator("internal:role=link[name=\"View Cart \"i]")
        
        await _loc_3.click()
    
    async with testmu.step('Extracting the current page title', instruction_id='024cc7004d6c435d87e58eaa3d6ce885'):
        set_var('shopping_cart_check', await page.title())
    
    async with testmu.step('Shopping Cart', instruction_id='0a036ec789734c248ecaf807569edae2'):
        await testmu.verify_assertion(page, 'Shopping Cart', {'operator': ['equals'], 'assertion_operands': [], 'left_operand': None, 'right_operand': None, 'operands': [], 'sub_checks': [{'description': 'Shopping Cart', 'store_key': 'shopping_cart_check', 'expected_value': 'Shopping Cart', 'operator': 'equals', 'transforms': [], 'extracted_value': '{{shopping_cart_check}}', 'variable_refs': {'{{shopping_cart_check}}': 'Shopping Cart'}, 'json_path': None}], 'composite_operator': 'and', 'verification': 'Shopping Cart is present in the current page state.', 'claim': 'Shopping Cart'})


if __name__ == "__main__":
    testmu.run(test)