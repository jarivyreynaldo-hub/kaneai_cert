import os
import testmu
from testmu import expect, var, set_var
from playwright.async_api import Page

testmu.configure(
    build="64bd6459-723c-459c-89a7-8ff5066319d4",
    name="Access and Verify User Account Sections",
    tc_id="TC-105",
    network=os.getenv("NETWORK", "false").lower() == "true",
    variables={"my_account_visible": "true", "my_orders_visible": "true", "my_affiliate_account_visible": "true", "my_wish_list_present": "true"},
    test_params={"Email": "prince.ronquillo@bnext.tech", "email_address_cert": "test.account@gmail.com", "Email_PCR": "test.account@gmail.com", "login_cert": "test.account@gmail.com", "Password": "Pcr!199617pcr2", "password_cert": "Testaccount123", "Username": "PRONQUILLO"},
    global_variables=[{"id": 143728, "name": "Asset_Class", "value": "3200", "session_value": "3200", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 143727, "name": "Company_Code", "value": "5810", "session_value": "5810", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 143752, "name": "Cost_Center", "value": "58101501", "session_value": "58101501", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 337953, "name": "product_cert", "value": "iPhone", "session_value": "iPhone", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 133664, "name": "Username", "value": "PRONQUILLO", "session_value": "PRONQUILLO", "is_persist": False, "environment_id": 0, "environment_name": "No Env"}],
    auto_heal_version="AH2",
    default_action_timeout_ms=60000,
    default_navigation_timeout_ms=60000,
    kane_run_v4=True,
)

@testmu.test
async def test(page: Page):
    async with testmu.step('Navigating to the ecommerce playground home page', instruction_id='12758806bfcb45c3a0b3be821d2bca8f'):
        await page.goto("https://ecommerce-playground.lambdatest.io/index.php?route=common/home")
    
    async with testmu.step('Scroll into view: PRIMARY: My account link; role=link; text="My account" | HINTS: container=Quick Links header navigation', instruction_id='3bccbfb611104d02b8786b70627eb551'):
        element_0 = page.locator("internal:role=link[name=\" My account\"i]")
        await element_0.evaluate("el => el.scrollIntoView({block: 'center'})")
    
    async with testmu.step('PRIMARY: My account link; role=link; text="My account" | HINTS: container=Quick Links header navigation', instruction_id='0e69f10a7a534d40853fe5698949e816'):
        coords = await testmu.get_vision_coordinates(page, 'PRIMARY: My account link; role=link; text="My account" | HINTS: container=Quick Links header navigation', "click", 1011, 103)
        await page.mouse.click(coords['x'], coords['y'])
        
    
    async with testmu.step('Waiting for the queued plan to continue', instruction_id='c3ba0c6051ab44c087b9df91243fef90'):
        await page.wait_for_timeout(1000)
    
    async with testmu.step('Type "{{secrets.user.login_cert}}" into "E-Mail Address"', instruction_id='e10132e144384d34a03eb7185d240a63'):
        element_1 = page.locator("internal:role=textbox[name=\"E-Mail Address\"i]")
        variable_value_2 = var('{{secrets.user.login_cert}}')
        
        try:
            await element_1.click(timeout=2000)
        except Exception:
            pass
        await element_1.fill(testmu.as_text(variable_value_2))
    
    async with testmu.step('Type "{{secrets.user.password_cert}}" into "Password"', instruction_id='1a633c504e7341dba81a0de5cba69dca'):
        element_3 = page.locator("internal:role=textbox[name=\"Password\"i]")
        variable_value_4 = var('{{secrets.user.password_cert}}')
        
        try:
            await element_3.click(timeout=2000)
        except Exception:
            pass
        await element_3.fill(testmu.as_text(variable_value_4))
    
    async with testmu.step('Clicking the Returning Customer Login button', instruction_id='e9f9cf3e607941b1af5414f02fdf8087'):
        _loc_1 = page.locator("internal:role=button[name=\"Login\"i]")
        
        await _loc_1.click()
    
    async with testmu.step('Checking whether the My Account heading is visible'):
        set_var('my_account_visible', await testmu.textual_analyzer(page, wrapped_js="(els) => {\n  const __m = {160: 0};\n  const el = (i) => els[__m[i]];\n  const __v = (!!el(160) && el(160).getClientRects().length > 0 && getComputedStyle(el(160)).visibility !== 'hidden' && getComputedStyle(el(160)).display !== 'none');\n  return (typeof __v === 'boolean' ? String(__v) : __v);\n}", locators=['internal:role=heading[name="My Account"i]'], query='whether the My Account heading is visible', expected_value='true', needs_unit_conversion=False, operator='equals', transforms=[], condition='My Account is visible'))
    
    async with testmu.step('My Account is visible', instruction_id='f171efca747f49b08d03b2815e39789e'):
        await testmu.verify_assertion(page, 'My Account is visible', {'operator': ['equals'], 'assertion_operands': [], 'left_operand': None, 'right_operand': None, 'operands': [], 'sub_checks': [{'description': 'My Account is visible', 'store_key': 'my_account_visible', 'expected_value': 'true', 'operator': 'equals', 'transforms': [], 'extracted_value': '{{my_account_visible}}', 'variable_refs': {'{{my_account_visible}}': 'true'}, 'json_path': None}], 'composite_operator': 'and', 'verification': 'My Account is visible on the current page.', 'claim': 'My Account is visible'})
    
    async with testmu.step('Checking whether the My Orders section is present'):
        set_var('my_orders_visible', await testmu.textual_analyzer(page, wrapped_js="(els) => {\n  const __m = {167: 0};\n  const el = (i) => els[__m[i]];\n  const __v = (!!el(167) && /My Orders/i.test(el(167).textContent || ''));\n  return (typeof __v === 'boolean' ? String(__v) : __v);\n}", locators=['internal:role=heading[name="My Orders"i]'], query='whether the My Orders section heading is present', expected_value='true', needs_unit_conversion=False, operator='equals', transforms=[], condition='My Orders is visible'))
    
    async with testmu.step('My Orders is visible', instruction_id='ddca8e70f7894f5f85db2d7355d7f04b'):
        await testmu.verify_assertion(page, 'My Orders is visible', {'operator': ['equals'], 'assertion_operands': [], 'left_operand': None, 'right_operand': None, 'operands': [], 'sub_checks': [{'description': 'My Orders is visible', 'store_key': 'my_orders_visible', 'expected_value': 'true', 'operator': 'equals', 'transforms': [], 'extracted_value': '{{my_orders_visible}}', 'variable_refs': {'{{my_orders_visible}}': 'true'}, 'json_path': None}], 'composite_operator': 'and', 'verification': 'My Orders is visible', 'claim': 'My Orders is visible'})
    
    async with testmu.step('Checking whether the My Affiliate Account section is visible'):
        set_var('my_affiliate_account_visible', await testmu.textual_analyzer(page, wrapped_js="(els) => {\n  const __m = {175: 0};\n  const el = (i) => els[__m[i]];\n  const __v = (el(175).textContent.trim() === 'My Affiliate Account');\n  return (typeof __v === 'boolean' ? String(__v) : __v);\n}", locators=['internal:role=heading[name="My Affiliate Account"i]'], query='whether the My Affiliate Account section heading is present', expected_value='true', needs_unit_conversion=False, operator='equals', transforms=[], condition='My Affiliate Account is visible'))
    
    async with testmu.step('My Affiliate Account is visible', instruction_id='4cf38128c8e44b47a2fb660309b0f5ee'):
        await testmu.verify_assertion(page, 'My Affiliate Account is visible', {'operator': ['equals'], 'assertion_operands': [], 'left_operand': None, 'right_operand': None, 'operands': [], 'sub_checks': [{'description': 'My Affiliate Account is visible', 'store_key': 'my_affiliate_account_visible', 'expected_value': 'true', 'operator': 'equals', 'transforms': [], 'extracted_value': '{{my_affiliate_account_visible}}', 'variable_refs': {'{{my_affiliate_account_visible}}': 'true'}, 'json_path': None}], 'composite_operator': 'and', 'verification': 'My Affiliate Account is visible on the current page', 'claim': 'My Affiliate Account is visible'})
    
    async with testmu.step('Scroll into view: PRIMARY: Wish List navigation link; role=link; text="\uf004 Wishlist" | HINTS: container=Quick Links menu', instruction_id='c437953d04c44ca7a53423033d881e1b'):
        element_5 = page.locator("internal:role=link[name=\" Wishlist\"i]")
        await element_5.evaluate("el => el.scrollIntoView({block: 'center'})")
    
    async with testmu.step('PRIMARY: Wish List navigation link; role=link; text="\uf004 Wishlist" | HINTS: container=Quick Links menu', instruction_id='5876d100b8034dd489a6bdf0f135d2ca'):
        coords = await testmu.get_vision_coordinates(page, 'PRIMARY: Wish List navigation link; role=link; text="\uf004 Wishlist" | HINTS: container=Quick Links menu', "click", 1158, 457)
        await page.mouse.click(coords['x'], coords['y'])
        
    
    async with testmu.step('Checking whether My Wish List is present'):
        set_var('my_wish_list_present', await testmu.textual_analyzer(page, wrapped_js="(els) => {\n  const __m = {161: 0};\n  const el = (i) => els[__m[i]];\n  const __v = (el(161).textContent.trim() === 'My Wish List');\n  return (typeof __v === 'boolean' ? String(__v) : __v);\n}", locators=['internal:role=heading[name="My Wish List"i]'], query='whether My Wish List is present on the current page', expected_value='true', needs_unit_conversion=False, operator='equals', transforms=[], condition='My Wish List is present on the current page.'))
    
    async with testmu.step('My Wish List is present on the current page.', instruction_id='40c28386754643f5beaca6081182ab4c'):
        await testmu.verify_assertion(page, 'My Wish List is present on the current page.', {'operator': ['equals'], 'assertion_operands': [], 'left_operand': None, 'right_operand': None, 'operands': [], 'sub_checks': [{'description': 'My Wish List is present on the current page.', 'store_key': 'my_wish_list_present', 'expected_value': 'true', 'operator': 'equals', 'transforms': [], 'extracted_value': '{{my_wish_list_present}}', 'variable_refs': {'{{my_wish_list_present}}': 'true'}, 'json_path': None}], 'composite_operator': 'and', 'verification': 'My Wish List is present on the current page.', 'claim': 'My Wish List is present on the current page.'})


if __name__ == "__main__":
    testmu.run(test)