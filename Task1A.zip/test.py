import os
import testmu
from testmu import expect, var, set_var
from playwright.async_api import Page

testmu.configure(
    build="d96b4b28-ff88-4f4d-90f8-7d1e09c57161",
    name="User Registration and Login Verification",
    tc_id="TC-93",
    network=os.getenv("NETWORK", "false").lower() == "true",
    variables={"email": "mtugn4p3x8@example.com", "password": "Password", "my_account_visible": "true", "my_orders_visible": "true", "affiliate_account_visible": "true"},
    test_params={"Email": "prince.ronquillo@bnext.tech", "login_cert": "test.account@gmail.com", "Password": "Pcr!199617pcr2", "password_cert": "Testaccount123", "Username": "PRONQUILLO"},
    global_variables=[{"id": 143728, "name": "Asset_Class", "value": "3200", "session_value": "3200", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 143727, "name": "Company_Code", "value": "5810", "session_value": "5810", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 143752, "name": "Cost_Center", "value": "58101501", "session_value": "58101501", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 337944, "name": "product_test", "value": "iPhone", "session_value": "iPhone", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 133664, "name": "Username", "value": "PRONQUILLO", "session_value": "PRONQUILLO", "is_persist": False, "environment_id": 0, "environment_name": "No Env"}],
    auto_heal_version="AH2",
    default_action_timeout_ms=60000,
    default_navigation_timeout_ms=60000,
    kane_run_v4=True,
)

@testmu.test
async def test(page: Page):
    async with testmu.step('Navigate to https://ecommerce-playground.lambdatest.io/index.php?route=common/home', instruction_id='78cfb5659dc04fe58a19b7e7ccee7879'):
        await page.goto("https://ecommerce-playground.lambdatest.io/index.php?route=common/home")
    
    async with testmu.step('Scroll into view: PRIMARY: My account link; role=link; text="\uf406 My account" | HINTS: container=Quick Links header navigation', instruction_id='baf241135a05427f9d689898c08c68ef'):
        element_0 = page.locator("internal:role=link[name=\" My account\"i]")
        await element_0.evaluate("el => el.scrollIntoView({block: 'center'})")
    
    async with testmu.step('PRIMARY: My account link; role=link; text="\uf406 My account" | HINTS: container=Quick Links header navigation', instruction_id='92b4bb6b45ee4eacaf0bf658728c95cc'):
        coords = await testmu.get_vision_coordinates(page, 'PRIMARY: My account link; role=link; text="\uf406 My account" | HINTS: container=Quick Links header navigation', "click", 1013, 103)
        await page.mouse.click(coords['x'], coords['y'])
        
    
    async with testmu.step('Clicking the Register link in the right account sidebar', instruction_id='52b8477edf46475a90455459b5f8c2cb'):
        _loc_1 = page.locator("internal:role=link[name=\" Register\"i]")
        
        await _loc_1.click()
    
    async with testmu.step('Entering first name Test', instruction_id='29261a60029f4f308c815cc4b888eaf3'):
        element_1 = page.locator("internal:role=textbox[name=\"First Name*\"i]")
        
        try:
            await element_1.click(timeout=2000)
        except Exception:
            pass
        await element_1.fill("Test")
    
    async with testmu.step('Typing last name in the last name input field', instruction_id='22cfdfb255ea481197b6d47cec9934b7'):
        element_2 = page.locator("internal:role=textbox[name=\"Last Name*\"i]")
        
        try:
            await element_2.click(timeout=2000)
        except Exception:
            pass
        await element_2.fill("Account")
    
    async with testmu.step('Typing a new email address into the email field', instruction_id='8ac33fd58e954b96b5d6f413a08d9d22'):
        element_3 = page.locator("internal:role=textbox[name=\"E-Mail*\"i]")
        variable_value_4 = var('{{smart.random_email}}')
        
        try:
            await element_3.click(timeout=2000)
        except Exception:
            pass
        await element_3.fill(testmu.as_text(variable_value_4))
    
    async with testmu.step('Reading the E-Mail textbox value'):
        set_var('email', await testmu.textual_analyzer(page, wrapped_js="(els) => {\n  const __m = {154: 0};\n  const el = (i) => els[__m[i]];\n  const __v = (el(154).value);\n  return (typeof __v === 'boolean' ? String(__v) : __v);\n}", locators=['internal:role=textbox[name="E-Mail*"i]'], query='the value in the E-Mail textbox in the Personal Details section of the registration form', expected_value='', needs_unit_conversion=False, operator='equals', transforms=['strip'], condition='PRIMARY: value in the required E-Mail textbox; role=textbox | HINTS: container=Personal Details section of the registration form'))
    
    async with testmu.step('Typing the telephone number', instruction_id='201d50fae0dd4a2daa2cc93722c628db'):
        element_5 = page.locator("internal:role=textbox[name=\"Telephone*\"i]")
        variable_value_6 = var('{{smart.random_phone}}')
        
        try:
            await element_5.click(timeout=2000)
        except Exception:
            pass
        await element_5.fill(testmu.as_text(variable_value_6))
    
    async with testmu.step('Typing password in the registration form password field', instruction_id='f9afdf3855a94bdfa162764ec35b4442'):
        element_7 = page.locator("internal:role=textbox[name=\"Password*\"i]")
        
        try:
            await element_7.click(timeout=2000)
        except Exception:
            pass
        await element_7.fill("Password")
    
    async with testmu.step('Extracting the entered registration password value'):
        set_var('password', await testmu.textual_analyzer(page, wrapped_js="(els) => {\n  const __m = {161: 0};\n  const el = (i) => els[__m[i]];\n  const __v = (el(161).value);\n  return (typeof __v === 'boolean' ? String(__v) : __v);\n}", locators=['internal:role=textbox[name="Password*"i]'], query='the exact unmasked value entered in the registration form Password field', expected_value='', needs_unit_conversion=False, operator='equals', transforms=['strip'], condition='PRIMARY: the exact unmasked value currently entered in the registration form\'s "Password *" field; role=textbox | HINTS: container=Your Password section'))
    
    async with testmu.step('Typing password confirmation', instruction_id='fa1d5370f17240618b9c6e781fd3ab63'):
        element_8 = page.locator("internal:role=textbox[name=\"Password Confirm*\"i]")
        
        try:
            await element_8.click(timeout=2000)
        except Exception:
            pass
        await element_8.fill("Password")
    
    async with testmu.step('Scroll into view: PRIMARY: Privacy Policy consent checkbox; role=checkbox; text="I have read and agree to the Privacy Policy" | HINTS: container=bottom of registration form', instruction_id='9288591ee38e4e0ea1d4f6c37100774e'):
        element_9 = page.locator("internal:role=checkbox[name=\"I have read and agree to the\"i]")
        await element_9.evaluate("el => el.scrollIntoView({block: 'center'})")
    
    async with testmu.step('PRIMARY: Privacy Policy consent checkbox; role=checkbox; text="I have read and agree to the Privacy Policy" | HINTS: container=bottom of registration form', instruction_id='b9a9ee542e8140f99a3d9320090d8d5a'):
        coords = await testmu.get_vision_coordinates(page, 'PRIMARY: Privacy Policy consent checkbox; role=checkbox; text="I have read and agree to the Privacy Policy" | HINTS: container=bottom of registration form', "click", 548, 654)
        await page.mouse.click(coords['x'], coords['y'])
        
    
    async with testmu.step('Clicking Continue to submit registration', instruction_id='e4da5c5b486c42c78fbbfe2f517c050c'):
        _loc_2 = page.locator("internal:role=button[name=\"Continue\"i]")
        
        await _loc_2.click()
    
    async with testmu.step('Scroll into view: PRIMARY: Log out link; role=link; text="Logout" | HINTS: container=My Account sidebar navigation', instruction_id='7e0c3160caf84981b9be22eab57b53c4'):
        element_10 = page.locator("internal:role=link[name=\" Logout\"i]")
        await element_10.evaluate("el => el.scrollIntoView({block: 'center'})")
    
    async with testmu.step('Clicking Logout link in My Account sidebar', instruction_id='cc5c9adec9d143f8ab132d9fd5dfe0ab'):
        _loc_3 = page.locator("internal:role=link[name=\" Logout\"i]")
        
        await _loc_3.click()
    
    async with testmu.step('Clicking the Login link in the account navigation panel', instruction_id='96093dfc733247b9ab116846c3cac6f9'):
        _loc_4 = page.locator("internal:role=link[name=\" Login\"i]")
        
        await _loc_4.click()
    
    async with testmu.step('Typing the email address', instruction_id='7bd66737a8ba47b5ab47056975c45c35'):
        element_11 = page.locator("internal:role=textbox[name=\"E-Mail Address\"i]")
        variable_value_12 = var('{{email}}')
        
        try:
            await element_11.click(timeout=2000)
        except Exception:
            pass
        await element_11.fill(testmu.as_text(variable_value_12))
    
    async with testmu.step('Typing password into password field', instruction_id='2e501fab0165429bbe7c60d9331e37d3'):
        element_13 = page.locator("internal:role=textbox[name=\"Password\"i]")
        variable_value_14 = var('{{password}}')
        
        try:
            await element_13.click(timeout=2000)
        except Exception:
            pass
        await element_13.fill(testmu.as_text(variable_value_14))
    
    async with testmu.step('Clicking the Login submit button', instruction_id='f5c8a04089b84611abb10ac9a772ef21'):
        _loc_5 = page.locator("internal:role=button[name=\"Login\"i]")
        
        await _loc_5.click()
    
    async with testmu.step('Checking whether the My Account heading is visible'):
        set_var('my_account_visible', await testmu.textual_analyzer(page, wrapped_js="(els) => {\n  const __m = {142: 0};\n  const el = (i) => els[__m[i]];\n  const __v = (el(142).textContent.trim() === 'My Account');\n  return (typeof __v === 'boolean' ? String(__v) : __v);\n}", locators=['internal:role=heading[name="My Account"i]'], query='whether the My Account heading is visible', expected_value='true', needs_unit_conversion=False, operator='equals', transforms=[], condition='My Account is Visible'))
    
    async with testmu.step('My Account is Visible', instruction_id='ca01834c1ade4213a7c776827fc955a5'):
        await testmu.verify_assertion(page, 'My Account is Visible', {'operator': ['equals'], 'assertion_operands': [], 'left_operand': None, 'right_operand': None, 'operands': [], 'sub_checks': [{'description': 'My Account is Visible', 'store_key': 'my_account_visible', 'expected_value': 'true', 'operator': 'equals', 'transforms': [], 'extracted_value': '{{my_account_visible}}', 'variable_refs': {'{{my_account_visible}}': 'true'}, 'json_path': None}], 'composite_operator': 'and', 'verification': 'My Account is Visible', 'claim': 'My Account is Visible'})
    
    async with testmu.step('Checking whether the My Orders heading is present'):
        set_var('my_orders_visible', await testmu.textual_analyzer(page, wrapped_js="(els) => {\n  const __m = {149: 0};\n  const el = (i) => els[__m[i]];\n  const __v = (!!el(149) && ((el(149).innerText || el(149).textContent || '').trim() === 'My Orders'));\n  return (typeof __v === 'boolean' ? String(__v) : __v);\n}", locators=['internal:role=heading[name="My Orders"i]'], query='whether the My Orders heading is present', expected_value='true', needs_unit_conversion=False, operator='equals', transforms=[], condition='My Orders is visible'))
    
    async with testmu.step('My Orders is visible', instruction_id='2fa23989b67246228d0235614892b572'):
        await testmu.verify_assertion(page, 'My Orders is visible', {'operator': ['equals'], 'assertion_operands': [], 'left_operand': None, 'right_operand': None, 'operands': [], 'sub_checks': [{'description': 'My Orders is visible', 'store_key': 'my_orders_visible', 'expected_value': 'true', 'operator': 'equals', 'transforms': [], 'extracted_value': '{{my_orders_visible}}', 'variable_refs': {'{{my_orders_visible}}': 'true'}, 'json_path': None}], 'composite_operator': 'and', 'verification': 'My Orders is visible on the current page.', 'claim': 'My Orders is visible'})
    
    async with testmu.step('Checking whether the My Affiliate Account heading is present'):
        set_var('affiliate_account_visible', await testmu.textual_analyzer(page, wrapped_js="(els) => {\n  const __m = {157: 0};\n  const el = (i) => els[__m[i]];\n  const __v = (el(157).textContent.trim() === 'My Affiliate Account');\n  return (typeof __v === 'boolean' ? String(__v) : __v);\n}", locators=['internal:role=heading[name="My Affiliate Account"i]'], query='whether the My Affiliate Account section heading is present', expected_value='true', needs_unit_conversion=False, operator='equals', transforms=[], condition='My Affiliate Account is Visible'))
    
    async with testmu.step('My Affiliate Account is Visible', instruction_id='40fe14e84fb042ed86e8cf5483efee25'):
        await testmu.verify_assertion(page, 'My Affiliate Account is Visible', {'operator': ['equals'], 'assertion_operands': [], 'left_operand': None, 'right_operand': None, 'operands': [], 'sub_checks': [{'description': 'My Affiliate Account is Visible', 'store_key': 'affiliate_account_visible', 'expected_value': 'true', 'operator': 'equals', 'transforms': [], 'extracted_value': '{{affiliate_account_visible}}', 'variable_refs': {'{{affiliate_account_visible}}': 'true'}, 'json_path': None}], 'composite_operator': 'and', 'verification': 'My Affiliate Account is Visible', 'claim': 'My Affiliate Account is Visible'})


if __name__ == "__main__":
    testmu.run(test)