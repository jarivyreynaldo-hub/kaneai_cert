import os
import testmu
from testmu import expect, var, set_var
from playwright.async_api import Page

testmu.configure(
    build="35f0efdb-d403-428f-925b-bbef9c8b62f2",
    name="Access and Verify Account Order History",
    tc_id="TC-106",
    network=os.getenv("NETWORK", "false").lower() == "true",
    variables={"my_account_visible": "true", "my_orders_visible": "true", "my_affiliate_account_visible": "true", "order_history_visible": "true"},
    test_params={"Email": "prince.ronquillo@bnext.tech", "email_address_cert": "test.account@gmail.com", "Email_PCR": "test.account@gmail.com", "login_cert": "test.account@gmail.com", "Password": "Pcr!199617pcr2", "password_cert": "Testaccount123", "Username": "PRONQUILLO"},
    global_variables=[{"id": 143728, "name": "Asset_Class", "value": "3200", "session_value": "3200", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 143727, "name": "Company_Code", "value": "5810", "session_value": "5810", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 143752, "name": "Cost_Center", "value": "58101501", "session_value": "58101501", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 337953, "name": "product_cert", "value": "iPhone", "session_value": "iPhone", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 133664, "name": "Username", "value": "PRONQUILLO", "session_value": "PRONQUILLO", "is_persist": False, "environment_id": 0, "environment_name": "No Env"}],
    auto_heal_version="AH2",
    default_action_timeout_ms=60000,
    default_navigation_timeout_ms=60000,
    kane_run_v4=True,
)

@testmu.test
async def test(page: Page):
    async with testmu.step('Navigating to the ecommerce playground home page', instruction_id='94142a80307849b89a5b548a61875c93'):
        await page.goto("https://ecommerce-playground.lambdatest.io/index.php?route=common/home")
    
    async with testmu.step('Scroll into view: PRIMARY: My account link; role=link; text="My account" | HINTS: container=Quick Links header navigation', instruction_id='b6db045160734f2ea271c102dbf6a729'):
        element_0 = page.locator("internal:role=link[name=\" My account\"i]")
        await element_0.evaluate("el => el.scrollIntoView({block: 'center'})")
    
    async with testmu.step('PRIMARY: My account link; role=link; text="My account" | HINTS: container=Quick Links header navigation', instruction_id='f236b6344c4745eba4392b54d0ad93aa'):
        coords = await testmu.get_vision_coordinates(page, 'PRIMARY: My account link; role=link; text="My account" | HINTS: container=Quick Links header navigation', "click", 1011, 103)
        await page.mouse.click(coords['x'], coords['y'])
        
    
    async with testmu.step('Waiting for the queued plan to continue', instruction_id='903ca4f3e6f44992a4914afeae597657'):
        await page.wait_for_timeout(1000)
    
    async with testmu.step('Type "{{secrets.user.login_cert}}" into "E-Mail Address"', instruction_id='03b10067bc44484d9f3c42c8edd00bd3'):
        element_1 = page.locator("internal:role=textbox[name=\"E-Mail Address\"i]")
        variable_value_2 = var('{{secrets.user.login_cert}}')
        
        try:
            await element_1.click(timeout=2000)
        except Exception:
            pass
        await element_1.fill(testmu.as_text(variable_value_2))
    
    async with testmu.step('Type "{{secrets.user.password_cert}}" into "Password"', instruction_id='d13fc17279e2436fa0ea69462de4f408'):
        element_3 = page.locator("internal:role=textbox[name=\"Password\"i]")
        variable_value_4 = var('{{secrets.user.password_cert}}')
        
        try:
            await element_3.click(timeout=2000)
        except Exception:
            pass
        await element_3.fill(testmu.as_text(variable_value_4))
    
    async with testmu.step('Clicking the Returning Customer Login button', instruction_id='6e4425d8f8124cefbf96e76d24fc6ffc'):
        _loc_1 = page.locator("internal:role=button[name=\"Login\"i]")
        
        await _loc_1.click()
    
    async with testmu.step('Checking whether the My Account heading is visible'):
        set_var('my_account_visible', await testmu.textual_analyzer(page, wrapped_js="(els) => {\n  const __m = {160: 0};\n  const el = (i) => els[__m[i]];\n  const __v = (!!el(160) && el(160).getClientRects().length > 0 && getComputedStyle(el(160)).visibility !== 'hidden' && getComputedStyle(el(160)).display !== 'none');\n  return (typeof __v === 'boolean' ? String(__v) : __v);\n}", locators=['internal:role=heading[name="My Account"i]'], query='whether the My Account heading is visible', expected_value='true', needs_unit_conversion=False, operator='equals', transforms=[], condition='My Account is visible'))
    
    async with testmu.step('My Account is visible', instruction_id='91a51b607aa84e4ba1bed1f414aec178'):
        await testmu.verify_assertion(page, 'My Account is visible', {'operator': ['equals'], 'assertion_operands': [], 'left_operand': None, 'right_operand': None, 'operands': [], 'sub_checks': [{'description': 'My Account is visible', 'store_key': 'my_account_visible', 'expected_value': 'true', 'operator': 'equals', 'transforms': [], 'extracted_value': '{{my_account_visible}}', 'variable_refs': {'{{my_account_visible}}': 'true'}, 'json_path': None}], 'composite_operator': 'and', 'verification': 'My Account is visible on the current page.', 'claim': 'My Account is visible'})
    
    async with testmu.step('Checking whether the My Orders section is present'):
        set_var('my_orders_visible', await testmu.textual_analyzer(page, wrapped_js="(els) => {\n  const __m = {167: 0};\n  const el = (i) => els[__m[i]];\n  const __v = (!!el(167) && /My Orders/i.test(el(167).textContent || ''));\n  return (typeof __v === 'boolean' ? String(__v) : __v);\n}", locators=['internal:role=heading[name="My Orders"i]'], query='whether the My Orders section heading is present', expected_value='true', needs_unit_conversion=False, operator='equals', transforms=[], condition='My Orders is visible'))
    
    async with testmu.step('My Orders is visible', instruction_id='e939bafbef7142f98a2506305f15676f'):
        await testmu.verify_assertion(page, 'My Orders is visible', {'operator': ['equals'], 'assertion_operands': [], 'left_operand': None, 'right_operand': None, 'operands': [], 'sub_checks': [{'description': 'My Orders is visible', 'store_key': 'my_orders_visible', 'expected_value': 'true', 'operator': 'equals', 'transforms': [], 'extracted_value': '{{my_orders_visible}}', 'variable_refs': {'{{my_orders_visible}}': 'true'}, 'json_path': None}], 'composite_operator': 'and', 'verification': 'My Orders is visible', 'claim': 'My Orders is visible'})
    
    async with testmu.step('Checking whether the My Affiliate Account section is visible'):
        set_var('my_affiliate_account_visible', await testmu.textual_analyzer(page, wrapped_js="(els) => {\n  const __m = {175: 0};\n  const el = (i) => els[__m[i]];\n  const __v = (el(175).textContent.trim() === 'My Affiliate Account');\n  return (typeof __v === 'boolean' ? String(__v) : __v);\n}", locators=['internal:role=heading[name="My Affiliate Account"i]'], query='whether the My Affiliate Account section heading is present', expected_value='true', needs_unit_conversion=False, operator='equals', transforms=[], condition='My Affiliate Account is visible'))
    
    async with testmu.step('My Affiliate Account is visible', instruction_id='32b39b96aaa441e890bfe16794a62643'):
        await testmu.verify_assertion(page, 'My Affiliate Account is visible', {'operator': ['equals'], 'assertion_operands': [], 'left_operand': None, 'right_operand': None, 'operands': [], 'sub_checks': [{'description': 'My Affiliate Account is visible', 'store_key': 'my_affiliate_account_visible', 'expected_value': 'true', 'operator': 'equals', 'transforms': [], 'extracted_value': '{{my_affiliate_account_visible}}', 'variable_refs': {'{{my_affiliate_account_visible}}': 'true'}, 'json_path': None}], 'composite_operator': 'and', 'verification': 'My Affiliate Account is visible on the current page', 'claim': 'My Affiliate Account is visible'})
    
    async with testmu.step('Clicking Order History in My Account sidebar', instruction_id='7ded9c47f4074520870ca764e1131904'):
        _loc_2 = page.locator("internal:role=link[name=\" Order History\"i]")
        
        await _loc_2.click()
    
    async with testmu.step('Checking whether the Order History heading is present'):
        set_var('order_history_visible', await testmu.textual_analyzer(page, wrapped_js="(els) => {\n  const __m = {161: 0};\n  const el = (i) => els[__m[i]];\n  const __v = (el(161).textContent.trim() === 'Order History');\n  return (typeof __v === 'boolean' ? String(__v) : __v);\n}", locators=['internal:role=heading[name="Order History"i]'], query='whether the Order History heading is present', expected_value='true', needs_unit_conversion=False, operator='equals', transforms=[], condition='Order History is visible'))
    
    async with testmu.step('Order History is visible', instruction_id='eb5328f0536d4e8ba0af7f99f8e8195a'):
        await testmu.verify_assertion(page, 'Order History is visible', {'operator': ['equals'], 'assertion_operands': [], 'left_operand': None, 'right_operand': None, 'operands': [], 'sub_checks': [{'description': 'Order History is visible', 'store_key': 'order_history_visible', 'expected_value': 'true', 'operator': 'equals', 'transforms': [], 'extracted_value': '{{order_history_visible}}', 'variable_refs': {'{{order_history_visible}}': 'true'}, 'json_path': None}], 'composite_operator': 'and', 'verification': 'Order History is visible on the current page.', 'claim': 'Order History is visible'})


if __name__ == "__main__":
    testmu.run(test)