import os
import testmu
from testmu import expect, var, set_var
from playwright.async_api import Page

testmu.configure(
    build="28d4746d-ad01-41b1-b201-ca85449f2065",
    name="User Login and Account Overview",
    tc_id="TC-101",
    network=os.getenv("NETWORK", "false").lower() == "true",
    variables={"my_account_check": "true", "my_orders_check": "My Orders", "my_affiliate_account_check": "true"},
    test_params={"Email": "prince.ronquillo@bnext.tech", "email_address_cert": "test.account@gmail.com", "Email_PCR": "test.account@gmail.com", "login_cert": "test.account@gmail.com", "Password": "Pcr!199617pcr2", "password_cert": "Testaccount123", "Username": "PRONQUILLO"},
    global_variables=[{"id": 143728, "name": "Asset_Class", "value": "3200", "session_value": "3200", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 143727, "name": "Company_Code", "value": "5810", "session_value": "5810", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 143752, "name": "Cost_Center", "value": "58101501", "session_value": "58101501", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 337953, "name": "product_cert", "value": "iPhone", "session_value": "iPhone", "is_persist": True, "environment_id": 0, "environment_name": "No Env"}, {"id": 133664, "name": "Username", "value": "PRONQUILLO", "session_value": "PRONQUILLO", "is_persist": False, "environment_id": 0, "environment_name": "No Env"}],
    auto_heal_version="AH2",
    default_action_timeout_ms=60000,
    default_navigation_timeout_ms=60000,
    kane_run_v4=True,
)

@testmu.test
async def test(page: Page):
    async with testmu.step('Navigate to https://ecommerce-playground.lambdatest.io/index.php?route=common/home', instruction_id='5ddeaee931bd44c588c81b3c3df9e04e'):
        await page.goto("https://ecommerce-playground.lambdatest.io/index.php?route=common/home")
    
    async with testmu.step('Scroll into view: PRIMARY: My account link; role=link; text="My account" | HINTS: container=top navigation quick links', instruction_id='b46e81b135d548a7aaf1333f26d0a613'):
        element_0 = page.locator("internal:role=link[name=\" My account\"i]")
        await element_0.evaluate("el => el.scrollIntoView({block: 'center'})")
    
    async with testmu.step('PRIMARY: My account link; role=link; text="My account" | HINTS: container=top navigation quick links', instruction_id='4f9bf214f34e455e8637bb3ed8f81fa1'):
        coords = await testmu.get_vision_coordinates(page, 'PRIMARY: My account link; role=link; text="My account" | HINTS: container=top navigation quick links', "click", 1015, 103)
        await page.mouse.click(coords['x'], coords['y'])
        
    
    async with testmu.step('Waiting for the form fields to be ready', instruction_id='494095829d0f4465883111a3c5cbd28f'):
        await page.wait_for_timeout(1000)
    
    async with testmu.step('Type "${login_cert}" into "E-Mail Address"', instruction_id='edafc4098a274864afbbfca897956e87'):
        element_1 = page.locator("internal:role=textbox[name=\"E-Mail Address\"i]")
        variable_value_2 = var('${login_cert}')
        
        try:
            await element_1.click(timeout=2000)
        except Exception:
            pass
        await element_1.fill(testmu.as_text(variable_value_2))
    
    async with testmu.step('Type "${password_cert}" into "Password"', instruction_id='20c350775d3849948128e8a483c51e04'):
        element_3 = page.locator("internal:role=textbox[name=\"Password\"i]")
        variable_value_4 = var('${password_cert}')
        
        try:
            await element_3.click(timeout=2000)
        except Exception:
            pass
        await element_3.fill(testmu.as_text(variable_value_4))
    
    async with testmu.step('Clicking Login submit button', instruction_id='f2ef5ecb065b460f965990f7a0d1d492'):
        _loc_1 = page.locator("internal:role=button[name=\"Login\"i]")
        
        await _loc_1.click()
    
    async with testmu.step('Checking whether the My Account heading is present'):
        set_var('my_account_check', await testmu.textual_analyzer(page, wrapped_js="(els) => {\n  const __m = {160: 0};\n  const el = (i) => els[__m[i]];\n  const __v = (el(160).textContent.trim() === 'My Account');\n  return (typeof __v === 'boolean' ? String(__v) : __v);\n}", locators=['internal:role=heading[name="My Account"i]'], query='whether the My Account heading is present in the current page content', expected_value='true', needs_unit_conversion=False, operator='equals', transforms=[], condition='My Account is present in the current page state.'))
    
    async with testmu.step('My Account', instruction_id='1862f9c0731b4f1fab3ad3e719f91f49'):
        await testmu.verify_assertion(page, 'My Account', {'operator': ['equals'], 'assertion_operands': [], 'left_operand': None, 'right_operand': None, 'operands': [], 'sub_checks': [{'description': 'My Account is present in the current page state.', 'store_key': 'my_account_check', 'expected_value': 'true', 'operator': 'equals', 'transforms': [], 'extracted_value': '{{my_account_check}}', 'variable_refs': {'{{my_account_check}}': 'true'}, 'json_path': None}], 'composite_operator': 'and', 'verification': 'My Account is present in the current page state.', 'claim': 'My Account'})
    
    async with testmu.step('Reading the My Orders section heading'):
        set_var('my_orders_check', await testmu.textual_analyzer(page, wrapped_js="(els) => {\n  const __m = {167: 0};\n  const el = (i) => els[__m[i]];\n  const __v = (el(167).textContent.trim());\n  return (typeof __v === 'boolean' ? String(__v) : __v);\n}", locators=['internal:role=heading[name="My Orders"i]'], query='the My Orders section heading text', expected_value='My Orders', needs_unit_conversion=False, operator='equals', transforms=['strip'], condition='My Orders'))
    
    async with testmu.step('My Orders', instruction_id='678851ddb9ae4b098e53a51ca95e5368'):
        await testmu.verify_assertion(page, 'My Orders', {'operator': ['equals'], 'assertion_operands': [], 'left_operand': None, 'right_operand': None, 'operands': [], 'sub_checks': [{'description': 'My Orders', 'store_key': 'my_orders_check', 'expected_value': 'My Orders', 'operator': 'equals', 'transforms': ['strip'], 'extracted_value': '{{my_orders_check}}', 'variable_refs': {'{{my_orders_check}}': 'My Orders'}, 'json_path': None}], 'composite_operator': 'and', 'verification': 'My Orders is present in the current page state.', 'claim': 'My Orders'})
    
    async with testmu.step('Checking whether the My Affiliate Account section is present'):
        set_var('my_affiliate_account_check', await testmu.textual_analyzer(page, wrapped_js="(els) => {\n  const __m = {175: 0};\n  const el = (i) => els[__m[i]];\n  const __v = (el(175).textContent.trim() === 'My Affiliate Account');\n  return (typeof __v === 'boolean' ? String(__v) : __v);\n}", locators=['internal:role=heading[name="My Affiliate Account"i]'], query='whether the My Affiliate Account section is present on the current page', expected_value='true', needs_unit_conversion=False, operator='equals', transforms=[], condition='My Affiliate Account is present or displayed on the current page.'))
    
    async with testmu.step('My Affiliate Account', instruction_id='6084761d5d824c399b2781e812e188c2'):
        await testmu.verify_assertion(page, 'My Affiliate Account', {'operator': ['equals'], 'assertion_operands': [], 'left_operand': None, 'right_operand': None, 'operands': [], 'sub_checks': [{'description': 'My Affiliate Account is present or displayed on the current page.', 'store_key': 'my_affiliate_account_check', 'expected_value': 'true', 'operator': 'equals', 'transforms': [], 'extracted_value': '{{my_affiliate_account_check}}', 'variable_refs': {'{{my_affiliate_account_check}}': 'true'}, 'json_path': None}], 'composite_operator': 'and', 'verification': 'My Affiliate Account is present or displayed on the current page.', 'claim': 'My Affiliate Account'})


if __name__ == "__main__":
    testmu.run(test)